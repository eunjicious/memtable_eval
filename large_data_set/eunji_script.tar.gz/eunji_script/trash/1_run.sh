EXEC_DIR=/home/ubuntu/rocksdb
DB_DIR=/mnt/rocksdb
WAL_DISABLE=1 # 0: on 1: off
if [[ $WAL_DISABLE == 1 ]]; then
	ENABLE_PIPELINE=0
else
	ENABLE_PIPELINE=1
fi
DB_DIR=/tmp

#num=5000000
valsize=100
num_threads=1
#buffsize=1073741824
#buffsize=17179869184
buffsize=67108864
workload="fillseq,fillrandom,readseq,readrandom"

#rm -rf /tmp/rocks*
rm -rf $DB_DIR/rocks*

#echo "$EXEC_DIR/rocks_bench --key_size=16 --value_size=$valsize --disable_auto_compactions=1 --write_buffer_size=$buffsize --disable_wal=$WAL_DISABLE --sync=0 --verify_checksum=0 --threads=$num_threads --use_existing_db=0 --allow_concurrent_memtable_write=1 --benchmarks=$workload --memtablerep=$mrep --db=$DB_DIR --num=$num > $res"

if [[ $# < 4 ]]; then
	echo "Usage: ./sh mode num_threads storage op"
	echo "e.g: ./sh none 1 nvme 500000"
	exit
fi


mon=$1
num_threads=$2
num=$4
DB_DIR=/mnt/rocksdb

rm -rf $DB_DIR/*

_mrep="prefix_hash hash_linkedlist"
_mrep="skip_list cuckoo"

for mrep in $_mrep; do
	echo "=================================="
	echo $mrep ... $num_threads
	res="rocksdb"_"$3"_"$mrep"_"$num_threads".perf
	echo "$EXEC_DIR/rocks_bench --key_size=16 --value_size=$valsize --disable_auto_compactions=1 --write_buffer_size=$buffsize --disable_wal=$WAL_DISABLE --sync=0 --verify_checksum=0 --threads=$num_threads --use_existing_db=0 --allow_concurrent_memtable_write=0 --benchmarks=$workload --memtablerep=$mrep --db=$DB_DIR --num=$num --keys_per_prefix=10 --prefix_size=8 --enable_pipelined_write=$ENABLE_PIPELINE "
	$EXEC_DIR/rocks_bench --key_size=16 --value_size=$valsize --disable_auto_compactions=1 --write_buffer_size=$buffsize --disable_wal=$WAL_DISABLE --sync=0 --verify_checksum=0 --threads=$num_threads --use_existing_db=0 --allow_concurrent_memtable_write=0 --benchmarks=$workload --memtablerep=$mrep --db=$DB_DIR --num=$num --keys_per_prefix=10 --prefix_size=8 --enable_pipelined_write=$ENABLE_PIPELINE > $res
#	cat $res | grep ops | awk '{print "'"$mrep"'", $0}'
	cat $res | grep ops
done




