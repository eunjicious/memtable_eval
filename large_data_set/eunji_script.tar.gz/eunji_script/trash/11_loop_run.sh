
if [[ $# -lt 1 ]]; then
	echo "buff size"
	exit
fi
buff=$1
ops=5000000

storage="nvme"
for st in $storage; do
	th=1
	echo "" > all.rslt
	while [[ $th -lt 17 ]]; do
		echo "./1_run.sh none $th $st $ops"
		#echo "./0_run.sh none $th $st" >> all.rslt
		./1_run.sh none $th $st $ops >> all.rslt
		th=$((th+th))
		sleep 20
	done
	mv all.rslt all_"$buff"_eunji_nolog.rslt
done
