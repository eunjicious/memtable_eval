#REQUIRES : Executable files level_bench, rocks_bench is exist in current Directory.
#WORKLOADS : fillseq, readwhilewriting, fillrandom, overwrite, readseq.

########################### FLAGS #################################
#		--comprssionration=%lf
#		--histogram=%d
#		--use_existing_db=%d
#		--reuse_log=%d
#		--num=$d
#		--reads=%d
#		--threads=%d
#		--value_size=%d
#		--write_buffer_size=%d
#		--cache_size=%d
#		--bloom_bits=%d
#		--open_files=%d
#		--db=%s
###################################################################

########## Script Paths ################
leveldb_nocom_library=~/leveldb-origin-nocompaction/AfterBuild.sh
leveldb_persca_library=~/leveldb-scale-ver-backup/AfterBuild.sh
hyperleveldb_library=~/HyperLevelDB-nolog-nocompact/AfterBuild.sh

########## Some Variables ###############


if [[ $# -lt 4 ]]; then
	echo "No compaction, No Log, Only In-Memory workload"
	echo "Need more larger memory component then modify buffsize in this script file."
	echo "./.sh object_num value_size thread_num thread_max"
	echo "./.sh 1000000 16 16 1"
	exit
fi

## How many want to insert keys ?
num=$1

num_threads=$3
multiple=1		
max_threads=`expr ${4}`
## How large value size? (num)bytes.
valsize=`expr ${2}`

## how many objects are maintained in skiplist ?
buffsize=1073741824 # 1GB

#Prefix_Hasn Prefix Size..
pre_size=8

## Benchmark Workload
#workload="fillseq,fillrandom,overwrite,readseq"
#workloadarr=("fillseq" "fillrandom" "overwrite" "readseq")
workload="fillseq,readseq,fillrandom,readrandom"
workloadarr=("fillseq" "readseq" "fillrandom" "readrandom")
#workload="fillseq,overwrite,readwhilewriting,readseq"
#workloadarr=("fillseq" "readwhilewriting" "overwrite" "readseq")
#memtablerep=("skip_list" "prefix_hash" "hash_linkedlist" "cuckoo" "vector")
#memtablerep=("skip_list" "prefix_hash" "hash_linkedlist" "cuckoo")
memtablerep=("skip_list" "cuckoo")

## Output Result
levelout_nocom="level_bench_nocom.log"
levelout_persca="level_bench_persca.log"
hyperout="hyper_bench.log"
rocksout="rocks_bench.log"
result="result.out"

#################################################################

# Even if temporary file is exist, temporary files are forced to remove.
echo files cleaning ..............................
rm -rf /tmp/level*
rm -rf /tmp/rocks*
rm -rf /tmp/hyper*
rm -f $result

printf "workload\tvalsize\tskiplist\tprefixhash\thashlinkedlist\tcuckoo\tvector\n" >> $result
for(( ; $num_threads<=$max_threads ; num_threads+=$multiple )) ; do
	res=""
	echo $num
	echo RocksDB Benchmarking $num_threads threads...
	for mrep in "${memtablerep[@]}"; do
		echo $mrep performance measuring........
		rm -rf /tmp/rocks*
		res="rocks_"$mrep".log"
		if [ "$mrep" == "skip_list" ];then
			echo "nohup ./rocks_bench --key_size=16 --value_size=$valsize --disable_auto_compactions=1 --write_buffer_size=$buffsize --disable_wal=1 --sync=0 --verify_checksum=0 --threads=$num_threads --use_existing_db=0 --allow_concurrent_memtable_write=1 --benchmarks=$workload --memtablerep=$mrep --num=$num --keys_per_prefix=10"
#			./rocks_bench --key_size=16 --value_size=$valsize --disable_auto_compactions=1 --write_buffer_size=$buffsize --disable_wal=1 --sync=0 --verify_checksum=0 --threads=$num_threads --use_existing_db=0 --allow_concurrent_memtable_write=1 --benchmarks=$workload --memtablerep=$mrep --num=$num --keys_per_prefix=10 > $res
			./rocks_bench --key_size=16 --value_size=$valsize --disable_auto_compactions=1 --write_buffer_size=$buffsize --disable_wal=1 --sync=0 --verify_checksum=0 --threads=$num_threads --use_existing_db=0 --allow_concurrent_memtable_write=1 --benchmarks=$workload --memtablerep=$mrep --num=$num > $res
		else
			echo "nohup ./rocks_bench --key_size=16 --value_size=$valsize --disable_auto_compactions=1 --write_buffer_size=$buffsize --disable_wal=1 --sync=0 --verify_checksum=0 --threads=$num_threads --use_existing_db=0 --benchmarks=$workload --allow_concurrent_memtable_write=0 --memtablerep=$mrep --prefix_size=$pre_size --num=$num --keys_per_prefix=10"
#			./rocks_bench --key_size=16 --value_size=$valsize --disable_auto_compactions=1 --write_buffer_size=$buffsize --disable_wal=1 --sync=0 --verify_checksum=0 --threads=$num_threads --use_existing_db=0 --benchmarks=$workload --allow_concurrent_memtable_write=0 --memtablerep=$mrep --prefix_size=$pre_size --num=$num --keys_per_prefix=10 > $res
			./rocks_bench --key_size=16 --value_size=$valsize --disable_auto_compactions=1 --write_buffer_size=$buffsize --disable_wal=1 --sync=0 --verify_checksum=0 --threads=$num_threads --use_existing_db=0 --benchmarks=$workload --allow_concurrent_memtable_write=0 --memtablerep=$mrep --num=$num > $res
		fi
#	cat $res
	done

	for val in "${workloadarr[@]}";do
		output="$val $num_threads"
		for mrep in "${memtablerep[@]}"; do
		res="rocks_"$mrep".log"
		output=$output" $( grep "$val" $res | awk '{ print $5 }' )"
		done
		echo $output >> $result
		echo "Done ..............."
		cat $result
	done
	#num=`expr ${num} + ${num}`
done
