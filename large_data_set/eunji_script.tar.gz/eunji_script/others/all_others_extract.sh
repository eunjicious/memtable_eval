

if [[ $# -lt 3 ]]; then 
	echo "./.sh cuckoo hdd 16G"
	exit
fi

dev=$2
buff=$3
workloads="fillseq fillrand readseq readrand"

for w in $workloads; do
	if [[ $1 == "prefix_hash" ]]; then
		echo "$w threads prefix_hash"
		cat all_"$dev"_"$buff".rslt | grep $w | awk 'NR%2==1 {print "prehash-'"${dev}"'", int(NR/2)+1, $5}'
	else
		echo "$w threads skip"
		cat all_"$dev"_"$buff".rslt | grep $w | awk 'NR%2==0 {print "hashlink-'"${dev}"'",int(NR/2)+NR%2, $5}'
	fi
done
