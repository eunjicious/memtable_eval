
#if [[ $# -lt 1 ]]; then
#	echo "buff(MB)"
#fi
#buff=$1

disable_wal=1
#ops=5000000
#ops=3145728
tot_ops=`expr 100 \* 1024 \* 1024`
#tot_ops=`expr 1 \* 1024`
#ops=5000000
mrep="skip_list cuckoo"
mrep="prefixhash"
mrep="cuckoo"
mrep="prefix_hash"
mrep="hash_linkedlist"
#buff=16384
#buff=64
#
#for mr in $mrep; do
#	th=1
#	while [[ $th -lt 17 ]]; do
#		echo "./1_memtable_run.sh $mr $th $disable_wal $ops $buff"
#		./1_memtable_run.sh $mr $th $disable_wal $ops $buff
#		th=$((th+th))
#		sleep 20
#	done
#done
#

function run(){
	buff=$1
  	for mr in $mrep; do
		th=1
		while [[ $th -lt 17 ]]; do
			ops=`expr $tot_ops / $th`
			echo "./1_memtable_run.sh $mr $th $disable_wal $ops $buff"
			fname="$mr"_"$th"_"$disable_wal"_"$ops"_"$buff"
#			cat $fname.perf >> $fname.perf.bak
#			mv $fname.p2f.bak $fname.perf
			./1_memtable_run.sh $mr $th $disable_wal $ops $buff
			th=$((th+th))
#			sleep 20
		done
  	done
}

#run 64
#run 16384
run 32768
