
echo "complete" | /bin/mail -s "complete" "eunjicious@gmail.com" 
