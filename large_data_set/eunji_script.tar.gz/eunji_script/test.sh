
aa="a 
	b 
	c"

for x in $aa; do
	echo $x
done
